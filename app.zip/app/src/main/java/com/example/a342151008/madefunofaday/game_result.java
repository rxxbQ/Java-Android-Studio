package com.example.a342151008.madefunofaday;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.content.Intent;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by 342151008 on 2017-05-30.
 */

public class game_result extends Activity {
    private String death;
    private TextView deathReason;
    private Intent fromGameEvent;
    private Intent startInformation;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_result);

        fromGameEvent = getIntent();
        death = fromGameEvent.getExtras().getString("Reason");
        deathReason = (TextView) findViewById(R.id.deathLabel);
        deathReason.setText(String.format(death));



    }

    public void goToInformationPage(View v){
        if (v.getId()==R.id.RestartButton){
            startInformation = new Intent(game_result.this,game_information.class);
            startActivity(startInformation);
        }
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(false);
        Toast.makeText( this, "Don't try to cheat!!", Toast.LENGTH_LONG).show();
    }
}
