package com.example.a342151008.madefunofaday;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by zhang on 2017/5/31.
 */

public class game_win extends Activity {
    private String win;
    private TextView winReason;
    private Intent fromGameEvent;
    private Intent startInformation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_win);

        fromGameEvent = getIntent();
        win = fromGameEvent.getExtras().getString("Win");
        winReason = (TextView) findViewById(R.id.winLabel);
        winReason.setText(String.format(win));
    }

    public void goToInformationPage(View v){
        if (v.getId()==R.id.RestartButton){
            startInformation = new Intent(game_win.this,game_information.class);
            startActivity(startInformation);
        }
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(false);
        Toast.makeText( this, "Don't try to cheat!!", Toast.LENGTH_LONG).show();
    }
}
