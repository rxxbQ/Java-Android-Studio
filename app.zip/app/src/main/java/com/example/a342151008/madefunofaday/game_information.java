package com.example.a342151008.madefunofaday;

import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.CheckBox;
import android.view.View.OnClickListener;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.Toast;



public class game_information extends Activity {
    private CheckBox maleCheckBox;
    private CheckBox femaleCheckBox;
    private CheckBox otherCheckBox;
    private EditText userName;
    private Intent startEvent;
    private String passName;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_information);

        ImageView cuteBoyView=(ImageView) findViewById(R.id.cuteBoyImage);
        Drawable boyDrawable  = getResources().getDrawable(R.drawable.cuteboy);
        cuteBoyView.setImageDrawable(boyDrawable);

        ImageView cutegirlView =(ImageView) findViewById(R.id.cuteGirlImage);
        Drawable girlDrawable  = getResources().getDrawable(R.drawable.cutegirl);
        cutegirlView.setImageDrawable(girlDrawable);

        ImageView genderView =(ImageView) findViewById(R.id.genderImage);
        Drawable genderDrawable  = getResources().getDrawable(R.drawable.gender);
        genderView.setImageDrawable(genderDrawable);

        userName   = (EditText)findViewById(R.id.nameEditText);


        maleCheckBox = (CheckBox)findViewById(R.id.maleCheckBox);
        maleCheckBox.setOnClickListener(new CheckBoxListener());
        otherCheckBox = (CheckBox)findViewById(R.id.otherCheckBox);
        otherCheckBox.setOnClickListener(new CheckBoxListener());
        femaleCheckBox = (CheckBox)findViewById(R.id.femaleCheckBox);
        femaleCheckBox.setOnClickListener(new CheckBoxListener());
    }

    public void goToEventPage(View v){
        passName = userName.getText().toString();
        if (v.getId()==R.id.startButton){
            if((userName.getText().length() == 0)||((maleCheckBox.isChecked()==false)&&(femaleCheckBox.isChecked()==false)&&(otherCheckBox.isChecked()==false))){
                Toast.makeText( this, "Please enter your name and gender.", Toast.LENGTH_LONG).show();
            }
            else{
                startEvent = new Intent(game_information.this,game_event.class);
                if (maleCheckBox.isChecked()==true){
                    startEvent.putExtra("Gender","Male");
                }
                else if(femaleCheckBox.isChecked()==true){
                    startEvent.putExtra("Gender","Female");
                }
                else{
                    startEvent.putExtra("Gender","Other");
                }
                startEvent.putExtra("Name",passName);
                startActivity(startEvent);

            }
        }
    }

    class CheckBoxListener implements OnClickListener {
        @Override
        public void onClick( View v ) {
            if (v.getId() == R.id.maleCheckBox) {
                if (maleCheckBox.isChecked()) {
                    femaleCheckBox.setChecked(false);
                    otherCheckBox.setChecked(false);
                }
            }
            if (v.getId() == R.id.femaleCheckBox) {
                if (femaleCheckBox.isChecked()) {
                    maleCheckBox.setChecked(false);
                    otherCheckBox.setChecked(false);
                }
            }
            if (v.getId() == R.id.otherCheckBox) {
                if (otherCheckBox.isChecked()) {
                    maleCheckBox.setChecked(false);
                    femaleCheckBox.setChecked(false);
                }
            }
        }
    }
}
