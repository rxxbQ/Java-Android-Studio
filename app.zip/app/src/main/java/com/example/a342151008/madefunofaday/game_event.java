package com.example.a342151008.madefunofaday;



import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.content.Intent;
import android.widget.TextView;
import android.view.View.OnClickListener;
/**
 * Created by 342151008 on 2017-05-19.
 */
public class game_event extends Activity {
    private String name;
    private String gender;
    private TextView userName;
    private TextView userGender;
    private TextView eventHappen;
    private TextView[] characteristicLabelArray = new TextView[10];
    private String[] characteristicButtonOneArray = new String[10];
    private String[] characteristicButtontwoArray = new String[10];
    private String[] characteristicButtonthreeArray = new String[10];
    private String[][] deathButtonArray = new String[3][];
    private String[] eventArray = new String[12];
    private String[] choiceButtonOne = new String[12];
    private String[] choiceButtonTwo = new String[12];
    private String[] choiceButtonThree = new String[12];
    private Button firstButton;
    private Button secondButton;
    private Button thirdButton;
    private int counter = 0;
    private int labelOrder = 0;
    private Intent startResult;
    private Intent startWin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_event);


        ImageView eventView=(ImageView) findViewById(R.id.eventImage);
        Drawable drawable  = getResources().getDrawable(R.drawable.eventimage);
        eventView.setImageDrawable(drawable);

        Intent fromGameInformation = getIntent();
        gender = fromGameInformation.getExtras().getString("Gender");
        name = fromGameInformation.getExtras().getString("Name");




        userName = (TextView) findViewById(R.id.userName);
        userGender = (TextView) findViewById(R.id.userGender);
        eventHappen = (TextView) findViewById(R.id.eventHappenLabel);
        firstButton = (Button) findViewById(R.id.firstChoiceButton);
        secondButton = (Button) findViewById(R.id.secondChoiceButton);
        thirdButton = (Button) findViewById(R.id.thirdChoiceButton);
        OnClickListener buttonEventListener = new ButtonListener();
        firstButton.setOnClickListener( buttonEventListener );
        secondButton.setOnClickListener( buttonEventListener );
        thirdButton.setOnClickListener( buttonEventListener );

        characteristicLabelArray[0] = (TextView) findViewById(R.id.oneLabel);
        characteristicLabelArray[1] = (TextView) findViewById(R.id.twoLabel);
        characteristicLabelArray[2] = (TextView) findViewById(R.id.threeLabel);
        characteristicLabelArray[3] = (TextView) findViewById(R.id.fourLabel);
        characteristicLabelArray[4] = (TextView) findViewById(R.id.fiveLabel);
        characteristicLabelArray[5] = (TextView) findViewById(R.id.sixLabel);
        characteristicLabelArray[6] = (TextView) findViewById(R.id.sevenLabel);
        characteristicLabelArray[7] = (TextView) findViewById(R.id.eightLabel);
        characteristicLabelArray[8] = (TextView) findViewById(R.id.nineLabel);
        characteristicLabelArray[9] = (TextView) findViewById(R.id.tenLabel);

        deathButtonArray[0] = new String[1];
        deathButtonArray[1] = new String[3];
        deathButtonArray[2] = new String[3];

        deathButtonArray[0][0] = "name因为睡不着所以决定吃一瓶安眠药，第二天邻居发现了他的尸体。";
        deathButtonArray[1][0] = "assuming the date is a kidnapping carefully planned by name, the SWAT team tracks down the IP adress of the name and brutally murders him.";
        deathButtonArray[1][1] = "警察认为name是恐怖分子的一员，当场枪毙了name.";
        deathButtonArray[1][2] = "name越玩越兴奋，猝死在了电脑前";
        deathButtonArray[2][0] = "name gets up from his seat and starts to slap the teacher silly because the teacher has given a stupid question.\n" +
                "the teacher, enraged with name, grabs the metre stick and performs medieval fencing on name's body,killing him instantly.";
        deathButtonArray[2][1] = "name试图摸老虎的屁股，被老虎一口咬死";
        deathButtonArray[2][2] = "name学会了如何边玩边睡，从此走上了人生巅峰";


        characteristicButtonOneArray[0] = "Strong";
        characteristicButtonOneArray[1] = "近视";
        characteristicButtonOneArray[2] = "胆小";
        characteristicButtonOneArray[3] = "poor student";
        characteristicButtonOneArray[4] = "VIP of YouTube";
        characteristicButtonOneArray[5] = "Gay";
        characteristicButtonOneArray[6] = "Bad";
        characteristicButtonOneArray[7] = "Live in dream";
        characteristicButtonOneArray[8] = "Fall in love";
        characteristicButtonOneArray[9] = "die";

        characteristicButtontwoArray[0] =  "Nothing happen";
        characteristicButtontwoArray[1] = "内向";
        characteristicButtontwoArray[2] = "die";
        characteristicButtontwoArray[3] = "SmartA";
        characteristicButtontwoArray[4] = "poor";
        characteristicButtontwoArray[5] = "Man";
        characteristicButtontwoArray[6] = "die";
        characteristicButtontwoArray[7] = "狂犬病";
        characteristicButtontwoArray[8] = "Nothing happen";
        characteristicButtontwoArray[9] = "die";

        characteristicButtonthreeArray[0] =  "Bloody";
        characteristicButtonthreeArray[1] = "Electronic heroin";
        characteristicButtonthreeArray[2] = "Insane";
        characteristicButtonthreeArray[3] = "die";
        characteristicButtonthreeArray[4] = "top student";
        characteristicButtonthreeArray[5] = "Nothing happen";
        characteristicButtonthreeArray[6] = "Brave";
        characteristicButtonthreeArray[7] = "die";
        characteristicButtonthreeArray[8] = "Loser";
        characteristicButtonthreeArray[9] = "win";

        eventArray[0] =  "This morning, "+name+" had a massive headache, memories filled his head, he has remembered that he is a __________.";
        eventArray[1] = name + "_____________.";
        eventArray[2] = "While "+ name + "is calling for takeout food, he mistakenly dials for the president of the United States.";
        eventArray[3] = "During math class, the teacher ask the class to determine the amount of uphill roads in China.";
        eventArray[4] = name+ "often use his phone __________.";
        eventArray[5] = "在放学的路上，name遇上漂亮大姐姐邀请name和她去一个地方。";
        eventArray[6] = "name吃饭的时候突然收到一份没有写收货人的神秘快递，name一打开里面竟然是一个炸弹，旁边还有一张生日贺卡！";
        eventArray[7] = "name去了动物园，他很喜欢___，并上前摸了一摸。";
        eventArray[8] = "name走在街上，突然被一路人拦住。路人对name说：“接吻一下……”name_________.";
        eventArray[9] = "name晚上睡觉的时候想打游戏";


        choiceButtonOne[0] = "bodyguard";
        choiceButtonOne[1] = "like watch TV";
        choiceButtonOne[2] = "end the call right away";
        choiceButtonOne[3] = "amounts are equal";
        choiceButtonOne[4] = "watching YouTube";
        choiceButtonOne[5] = "感觉恶心";
        choiceButtonOne[6] = "送给别人";
        choiceButtonOne[7] = "皮卡丘";
        choiceButtonOne[8] = "答应";
        choiceButtonOne[9] = "继续睡觉养足精神";

        choiceButtonTwo[0] = "tourist guide";
        choiceButtonTwo[1] = "stay quiet";
        choiceButtonTwo[2] = "ask the president out for a date";
        choiceButtonTwo[3] = "insufficient given data";
        choiceButtonTwo[4] = "砸人";
        choiceButtonTwo[5] = "走！";
        choiceButtonTwo[6] = "报警！";
        choiceButtonTwo[7] = "狗";
        choiceButtonTwo[8] = "一脸懵逼";
        choiceButtonTwo[9] = "打游戏";

        choiceButtonThree[0] = "chef";
        choiceButtonThree[1] = "like play computer";
        choiceButtonThree[2] = "oh! My body!";
        choiceButtonThree[3] = "the F**k?";
        choiceButtonThree[4] = "read novel";
        choiceButtonThree[5] = "不跟陌生人走";
        choiceButtonThree[6] = "按下上面的按钮";
        choiceButtonThree[7] = "老虎";
        choiceButtonThree[8] = "转身就跑";
        choiceButtonThree[9] = "边睡边玩";





        userName.setText(String.format(name));
        userGender.setText(String.format(gender));
        eventHappen.setText(String.format(eventArray[counter]));
        firstButton.setText(choiceButtonOne[counter]);
        secondButton.setText(choiceButtonTwo[counter]);
        thirdButton.setText(choiceButtonThree[counter]);
    }

    class ButtonListener implements OnClickListener {
        @Override
        public void onClick(View v) {
            startResult = new Intent(game_event.this,game_result.class);
            startWin = new Intent(game_event.this,game_win.class);
            if (counter < 10) {
                if (v.getId() == R.id.firstChoiceButton) {
                    if (counter == 9) {
                        startResult.putExtra("Reason", deathButtonArray[0][0]);
                        startActivity(startResult);
                    }
                    else {
                        characteristicLabelArray[labelOrder].setText(characteristicButtonOneArray[counter]);
                        labelOrder += 1;
                        counter += 1;
                        eventHappen.setText(String.format(eventArray[counter]));
                        firstButton.setText(choiceButtonOne[counter]);
                        secondButton.setText(choiceButtonTwo[counter]);
                        thirdButton.setText(choiceButtonThree[counter]);
                    }
                }
                else if (v.getId() == R.id.secondChoiceButton) {
                    if (counter == 2) {
                        startResult.putExtra("Reason", deathButtonArray[1][0]);
                        startActivity(startResult);
                    }
                    else if (counter == 6) {
                        startResult.putExtra("Reason", deathButtonArray[1][1]);
                        startActivity(startResult);

                    }
                    else if (counter == 9){
                        startResult.putExtra("Reason", deathButtonArray[1][2]);
                        startActivity(startResult);

                    }
                    else {
                        characteristicLabelArray[labelOrder].setText(characteristicButtontwoArray[counter]);
                        labelOrder += 1;
                        counter += 1;
                        eventHappen.setText(String.format(eventArray[counter]));
                        firstButton.setText(choiceButtonOne[counter]);
                        secondButton.setText(choiceButtonTwo[counter]);
                        thirdButton.setText(choiceButtonThree[counter]);
                    }
                }
                else {
                    if (counter == 3) {
                        startResult.putExtra("Reason", deathButtonArray[2][0]);
                        startActivity(startResult);



                    }
                    else if (counter == 7) {
                        startResult.putExtra("Reason", deathButtonArray[2][1]);
                        startActivity(startResult);

                    }
                    else if (counter == 9){
                        startWin.putExtra("Win", deathButtonArray[2][2]);
                        startActivity(startWin);

                    }
                    else {
                        characteristicLabelArray[labelOrder].setText(characteristicButtonthreeArray[counter]);
                        labelOrder += 1;
                        counter += 1;
                        eventHappen.setText(String.format(eventArray[counter]));
                        firstButton.setText(choiceButtonOne[counter]);
                        secondButton.setText(choiceButtonTwo[counter]);
                        thirdButton.setText(choiceButtonThree[counter]);
                    }
                }

            }
        }
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(false);
        Toast.makeText( this, "Don't try to cheat!!", Toast.LENGTH_LONG).show();
    }

}
